Your scripts go here.
All script files have to have the ".script" file extension and must follow a special syntax.

Check out the openHAB documentation for more details:
http://docs.openhab.org/features/automation/ruledsl.html#scripts
